// Preloader effect

window.onload = function() {

    setTimeout(() => {

        document.getElementById("preloader").style.display = "none";

    }, 2000);

};

